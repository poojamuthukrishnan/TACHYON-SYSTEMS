import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';


export class GreetingAppStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const greetingLambda = new lambda.Function(this, 'GreetingLambda', {
      runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda'),
      handler: 'index.handler'
    });

    const api = new apigateway.LambdaRestApi(this, 'GreetingApi', {
      handler: greetingLambda,
      proxy: false,
    });

    const greet = api.root.addResource('greet');
    greet.addMethod('GET');

    // 👇 Output the API URL to terminal after deploy
    new cdk.CfnOutput(this, 'ApiUrl', {
      value: api.url ?? 'Something went wrong',
    });
  }
}
