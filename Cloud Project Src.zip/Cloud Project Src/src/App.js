import React, { useState } from 'react';

function App() {
  const [name, setName] = useState('');
  const [response, setResponse] = useState(null);

  const handleGreet = async () => {
    const res = await fetch(
      `https://138gem15q0.execute-api.ap-south-1.amazonaws.com/prod/greet?name=${name}`
    );
    const data = await res.json();
    setResponse(data);
  };

  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h1>Greeting App</h1>
      <input
        type="text"
        placeholder="Enter your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ padding: '10px', fontSize: '16px' }}
      />
      <button onClick={handleGreet} style={{ marginLeft: '10px', padding: '10px' }}>
        Greet
      </button>

      {response && (
        <div style={{ marginTop: '20px' }}>
          <h2>{response.greeting}</h2>
          <p>{response.quote}</p>
        </div>
      )}
    </div>
  );
}

export default App;
