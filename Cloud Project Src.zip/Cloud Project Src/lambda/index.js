exports.handler = async (event) => {
    // Get the 'name' query parameter
    const name = event.queryStringParameters?.name || 'Guest';

    // Array of quotes
    const quotes = [
      "Success usually comes to those who are too busy to be looking for it.",
    "The best way to get started is to quit talking and begin doing.",
    "Don't watch the clock; do what it does. Keep going.",
    "Hard work beats talent when talent doesn't work hard.",
    "Dream big and dare to fail.",
    "Believe you can and you're halfway there.",
    "Your limitation—it's only your imagination.",
    "Push yourself, because no one else is going to do it for you."
    ];

    // Pick a random quote
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

    // Response object
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*", // CORS header for browser requests
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            greeting: `Hi ${name}! 🌟`,
            quote: randomQuote
        })
    };

    return response;
};
